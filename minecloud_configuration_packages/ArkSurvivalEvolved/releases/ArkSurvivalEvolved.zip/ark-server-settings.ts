export const ARK_SERVER_NAME = 'MC_ARK';
export const ARK_WORLD = 'MC_DEDICATED';
export const ARK_PASSWORD = 'secret';